import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {

  prodId:String;
prodName:String;
 prodCategory:String;
 price:Number;
discount:Number;
validTime:String;
promoCode:String;
viewsCount:Number;
qty:Number;

  constructor(private http: HttpClient) { }
  // url = 'http://localhost:4200';
  // getData() {
  //   return this
  //           .http
  //           .get(`${this.url}/products`);
  //       }

  showproducts(category:string):Observable<Product[]>{
    let url = 'http://localhost:8876/';
    return this.http.get<Product[]>(url+category);
  }

}
