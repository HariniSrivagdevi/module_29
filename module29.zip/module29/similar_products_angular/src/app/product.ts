export class Product {

prodId:string;
prodName:string;
prodCategory:string;
price:Number;
discount:Number;
validTime:string;
promoCode:string;
viewsCount:Number;
qty:Number;


}
